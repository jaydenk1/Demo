#!/usr/bin/env python
import csv, json
from io import StringIO
import sys
from flask import Flask, request, send_file, jsonify, Response, render_template
from flask.helpers import make_response
#from healthstatus import check_log
#import panda as pd
csv_rows = []
with open('/home/logs/containerlogs.csv', "rt") as o:
    csv_file = csv.reader(o, delimiter=",")
    for row in csv_file:
        csv_rows.append(row)
    o.close()


app = Flask(__name__)




@app.route("/")
def api():
    return "This is a demo\n"


@app.route('/logcheck/<user_input>', methods=['GET'])
def logcheck(user_input):
   
    if user_input != 'healthy' and user_input != 'unhealthy':
        return make_response("Please try again. Only /logcheck/healthy or logcheck/unhealthy")
    else:
        rows = []
        for row in csv_rows:
            if user_input in row:
                rows.append(row)
        return make_response (json.dumps (rows))

	
if __name__=='__main__':
    app.run(host='0.0.0.0',port=8080)


# from flask import Flask,json, render_template, request

# @app.route("/logs",methods=['GET'])
# def read_logs(logs):
#     json_url = os.path.join("/home/logs","resource.json")
#     if request.method == 'GET':
#         data_json = json.load(open(json_url))
#         data = data_json['events']
#         year = request.view_args['year']
#         output_data = [x for x in data if x['year']==year]
        
#         #render template is always looking in tempate folder
#         return render_template('events.html',html_page_text=output_data)
#     elif request.method == 'POST':
#         year = request.form['year']

#         #case sensitive, so be careful!
#         id = request.form['ID']
#         category = request.form['category']
#         event = request.form['event']
#         event_yr= { "year":year,
#                     "id":id,
#                     "event_category":category,
#                     "event":event
#                     }

#         with open(json_url,"r+") as file:
#             data_json = json.load(file)
#             data_json["events"].append(event_yr)
#             json.dump(data_json, file)
        
#         #Adding text
#         text_success = "Data successfully added: " + str(event_yr)
#         return render_template('index.html', html_page_text=text_success